import sys, os

# Necessary to find all modules in this package... doesnt really work as expected.
sys.path.append(os.path.abspath('./myScripts'))